const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const Nano = require("nano");
const path = require("path"); // ⬅️ NEW: Required for serving static files

const app = express();
// Keep default CORS to avoid issues with browser tools/extensions, but complex policy removed
app.use(cors()); 
app.use(bodyParser.json());

// ------------------------------------
// 0. SERVE STATIC FRONTEND FILES ⬅️ NEW: Serves index.html from the 'public' directory
// The client requests (GET /) and API calls (/books) will all hit this server.
app.use(express.static(path.join(__dirname, '..', 'public')));
// ------------------------------------


// ------------------------------------
// 1. CONNECT TO COUCHDB
// ------------------------------------
// Changed 0.0.0.0 to 127.0.0.1 for security best practice on internal Droplet connections
const couchUrl = "http://admin:admin@127.0.0.1:5984"; 
const nano = Nano(couchUrl);

const dbName = "booksdb";
let booksDB;

// ------------------------------------
// 2. INITIALIZE DB
// ------------------------------------
async function initDB() {
  try {
    const allDBs = await nano.db.list();

    if (!allDBs.includes(dbName)) {
      console.log(`📘 Creating database ${dbName} ...`);
      await nano.db.create(dbName);
    } else {
      console.log(`📘 Database already exists: ${dbName}`);
    }

    booksDB = nano.db.use(dbName);
  } catch (err) {
    console.error("❌ DB Init Error:", err);
  }
}

initDB();

// ------------------------------------
// Helpers: generate custom IDs like 2501,2502,...
// ------------------------------------
async function getNextCustomId() {
  // safe default
  const prefix = 25; // year 2025 -> prefix '25'
  const startBase = prefix * 100 + 1; // 2501 (since 25*100 = 2500)
  // fetch all docs (lightweight: only ids)
  const data = await booksDB.list({ include_docs: false });

  // collect numeric ids that look like our pattern (e.g., 2501, 2502,...)
  const numericIds = data.rows
    .map(r => {
      const n = parseInt(r.id, 10);
      return Number.isFinite(n) ? n : NaN;
    })
    .filter(n => !isNaN(n) && n >= startBase);

  if (numericIds.length === 0) return startBase;

  const max = Math.max(...numericIds);
  return max + 1;
}

// ------------------------------------
// 3. GET ALL BOOKS
// ------------------------------------
app.get("/books", async (req, res) => {
  try {
    const result = await booksDB.list({ include_docs: true });

    const books = result.rows.map((row) => ({
      id: row.id, // numeric/id string like "2501"
      title: row.doc.title,
      author: row.doc.author,
    }));

    res.json(books);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch books" });
  }
});

// ------------------------------------
// 4. GET BOOK BY ID
// ------------------------------------
app.get("/books/:id", async (req, res) => {
  try {
    const doc = await booksDB.get(req.params.id);

    res.json({
      id: doc._id,
      title: doc.title,
      author: doc.author,
    });
  } catch (err) {
    res.status(404).json({ error: "Book not found" });
  }
});

// ------------------------------------
// 5. ADD BOOK (POST) — generates IDs 2501,2502,...
// ------------------------------------
app.post("/books", async (req, res) => {
  try {
    const { title, author } = req.body;

    if (!title || !author) {
      return res.status(400).json({ error: "Title & Author required" });
    }

    // generate custom numeric ID with prefix 25
    const nextId = await getNextCustomId();
    const idStr = String(nextId);

    // store doc with _id = idStr
    const result = await booksDB.insert({ _id: idStr, title, author });

    res.json({
      id: idStr,
      title,
      author,
      rev: result.rev
    });
  } catch (err) {
    console.error("Insert error:", err);
    res.status(500).json({ error: "Failed to add book" });
  }
});

// ------------------------------------
// 6. UPDATE BOOK (PUT)
// ------------------------------------
app.put("/books/:id", async (req, res) => {
  try {
    const bookId = req.params.id;
    const { title, author } = req.body;

    const existingDoc = await booksDB.get(bookId);

    const updated = await booksDB.insert({
      _id: bookId,
      _rev: existingDoc._rev,
      title,
      author,
    });

    res.json({
      id: bookId,
      title,
      author,
      rev: updated.rev
    });
  } catch (err) {
    console.error("Update error:", err);
    res.status(500).json({ error: "Failed to update book" });
  }
});

// ------------------------------------
// 7. DELETE BOOK
// ------------------------------------
app.delete("/books/:id", async (req, res) => {
  try {
    const id = req.params.id;

    const doc = await booksDB.get(id);
    await booksDB.destroy(id, doc._rev);

    res.json({ message: `Book ${id} deleted` });
  } catch (err) {
    console.error("Delete error:", err);
    res.status(500).json({ error: "Failed to delete book" });
  }
});

// ------------------------------------
// 8. START SERVER
// ------------------------------------
// Bind to 0.0.0.0 so NGINX can reach it locally
app.listen(3000, '0.0.0.0', () => {
  console.log("🚀 Server running on http://0.0.0.0:3000 (Internal)");
});
