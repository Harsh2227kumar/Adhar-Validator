import { supabase } from "../lib/supabase";

export default function LogoutButton() {
  return (
    <button
      style={{
        position: "fixed",
        top: 10,
        right: 10,
        zIndex: 1000,
      }}
      onClick={() => supabase.auth.signOut()}
    >
      Logout
    </button>
  );
}
