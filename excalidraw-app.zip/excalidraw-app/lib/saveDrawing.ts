import { supabase } from "./supabase";

export async function saveDrawing(scene: any) {
  const { data } = await supabase.auth.getUser();
  if (!data.user) return;

  await supabase.from("drawings").upsert({
    user_id: data.user.id,
    data: scene,
    updated_at: new Date(),
  });
}
